package com.example.chisteschuck;

public class Categoria {


    public String getNombre() {
        return null;
    }
}
